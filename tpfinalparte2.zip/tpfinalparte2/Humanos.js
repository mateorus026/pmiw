let animacionesMujer = {};
let animacionesMujerArmada = {};
let animacionesHombre = {};
let animacionesHombreArmado = {};


function preload() {

  //animaciones mujer sin arma
  animacionesMujer.caminar = {};
  animacionesMujer.caminar.izquierda = cargarSecuencia("data/atenienses/mujeres/sin_arma/caminar_a/", 9);
  animacionesMujer.caminar.abajo = cargarSecuencia("data/atenienses/mujeres/sin_arma/caminar_s/", 9);
  animacionesMujer.caminar.arriba = cargarSecuencia("data/atenienses/mujeres/sin_arma/caminar_w/", 9);
  animacionesMujer.derrota = cargarSecuencia("data/atenienses/mujeres/sin_arma/derrota/", 6);

  //animaciones mujer con arma
  animacionesMujerArmada.caminar = {};
  animacionesMujerArmada.ataque = {};

  animacionesMujerArmada.caminar.izquierda = cargarSecuencia("data/atenienses/mujeres/con_arma/caminar_a/", 9);
  animacionesMujerArmada.caminar.abajo = cargarSecuencia("data/atenienses/mujeres/con_arma/caminar_s/", 9);
  animacionesMujerArmada.caminar.arriba = cargarSecuencia("data/atenienses/mujeres/con_arma/caminar_w/", 9);
  animacionesMujerArmada.derrota = cargarSecuencia("data/atenienses/mujeres/con_arma/derrota/", 6);
  animacionesMujerArmada.ataque.izquierda = cargarSecuencia("data/atenienses/mujeres/con_arma/ataque_a/", 6);
  animacionesMujerArmada.ataque.abajo = cargarSecuencia("data/atenienses/mujeres/con_arma/ataque_s/", 6);
  animacionesMujerArmada.ataque.arriba = cargarSecuencia("data/atenienses/mujeres/con_arma/ataque_w/", 6);

  //animaciones hombre sin arma
  animacionesHombre.caminar = {};
  animacionesHombre.caminar.izquierda = cargarSecuencia("data/atenienses/hombres/sin_arma/caminar_a/", 9);
  animacionesHombre.caminar.abajo = cargarSecuencia("data/atenienses/hombres/sin_arma/caminar_s/", 9);
  animacionesHombre.caminar.arriba = cargarSecuencia("data/atenienses/hombres/sin_arma/caminar_w/", 9);
  animacionesHombre.derrota = cargarSecuencia("data/atenienses/hombres/sin_arma/derrota/", 6);

  //animaciones hombre con arma
  animacionesHombreArmado.caminar = {};
  animacionesHombreArmado.ataque = {};

  animacionesHombreArmado.caminar.izquierda = cargarSecuencia("data/atenienses/hombres/con_arma/caminar_a/", 8);
  animacionesHombreArmado.caminar.abajo = cargarSecuencia("data/atenienses/hombres/con_arma/caminar_s/", 9);
  animacionesHombreArmado.caminar.arriba = cargarSecuencia("data/atenienses/hombres/con_arma/caminar_w/", 9);
  animacionesHombreArmado.derrota = cargarSecuencia("data/atenienses/hombres/con_arma/derrota/", 6);
  animacionesHombreArmado.ataque.izquierda = cargarSecuencia("data/atenienses/hombres/con_arma/ataque_a/", 6);
  animacionesHombreArmado.ataque.abajo = cargarSecuencia("data/atenienses/hombres/con_arma/ataque_s/", 6);
  animacionesHombreArmado.ataque.arriba = cargarSecuencia("data/atenienses/hombres/con_arma/ataque_w/", 6); 
}




class Humano {
  constructor() {
    
  }

  morir() {
   
  }

  dibujar() {
    
}
}