
class HiloDorado {
  constructor(puntosCamino) {
    this.camino = puntosCamino;
    this.colorGlow = '#d4af37'; 
  }

  dibujar(posAsterion, radioVision) {
  }
}
