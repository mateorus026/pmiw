let animacionesAsterion = {};

function preload() {
  //animaciones de Asterion
  animacionesAsterion.ataque = cargarSecuencia("data/asterion/ataque/", 10);
  animacionesAsterion.caminar = cargarSecuencia("data/asterion/caminar/", 5);
  animacionesAsterion.derrota = cargarSecuencia("data/asterion/derrota/", 6);

}

class Asterion {
  constructor(x, y) {
    
  }

  dibujar() {
    push();
    translate(this.x, this.y);
    rotate(this.orientacion + HALF_PI);
    
    let imgActual = this.animador.obtenerImagenActual();
    if (imgActual) {
      imageMode(CENTER);
      image(imgActual, 0, 0, 64, 64); 
    } else {
     
      fill(70, 20, 30);
      ellipse(0, 0, 32, 32);
    }
    
    pop();
  }

  atacar() {
    
  }
}
