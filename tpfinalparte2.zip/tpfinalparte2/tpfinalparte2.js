
let miJuego = new Juego();


function cargarSecuencia(rutaBase, totalFrames) {
  let frames = [];
  for (let i = 0; i < totalFrames; i++) {
    frames.push(loadImage(rutaBase + i + ".png"));
  }
  return frames;
}


function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(15);

  miJuego.actualizar();
  miJuego.dibujar();
}
