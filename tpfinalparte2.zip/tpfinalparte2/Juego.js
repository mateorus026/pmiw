
class Juego {
  constructor() {
    
  }

  inicializarNivel() {
 
  }



  dibujar() {
    
  }


  dibujarPantallaInicio() {
    
  }

  dibujarPantallaVictoria() {
    
  }

  dibujarPantallaDerrota() {
    
  }

}


